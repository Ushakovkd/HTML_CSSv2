import { landing } from './landing.js';

landing.load();