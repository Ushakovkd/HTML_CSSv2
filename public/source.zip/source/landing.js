class Landing {
    load() {
        
    }
}

export const landing = new Landing();